
    part of my coding snippet library, for easier coding bkp.
    f::will be backupped weekly onto usb stick!
  
